/* 
 * File:   main.cpp
 * Author: Stephen Boggs
 * Created on March 17, 2014, 9:32 AM
 * Purpose: if statements example
 */

//Include System Libraries
#include <cstdlib>//random number generator seed
#include <iostream>//I/O stream
#include <ctime>//Gives the time function
using namespace std;

//Global constants

//Function prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Set the random number seed and declare variable
    srand(static_cast<unsigned int>(time(0)));
    char score=rand()%51+50;//[50,100]
    char grade;
    //What score corresponds with the correct grade
    switch(score>89){
     case true: grade='A';break;
     default:
       switch(score>79){
         case true: grade='B';break;
         case false: 
           switch(score>69){
             case true: grade='C';break;
             default:
               switch(score>59){
                 case true: grade='D';break;
                 default: grade='F';
               }                 
           }                    
       }
    }                               
    //Output the results
    cout<<"A score of "<<static_cast<int>(score);
    cout<<" gives a grade = "<<grade<<endl;
    //exit stage right
    return 0;
}