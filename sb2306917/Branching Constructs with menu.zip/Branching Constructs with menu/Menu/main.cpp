/* 
 * File:   main.cpp
 * Author: Stephen Boggs
 * Created on March 17, 2014, 9:32 AM
 * Purpose: How to create a menu
 */

//Include System Libraries
#include <iostream>//I/O stream
using namespace std;

//Global constants

//Function prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    unsigned short choose;
    //Prompt user for number of problem to execute
    cout<<"Choose from the following list:"<<endl;
    cout<<"1. Savitch 8ed Chap3 Prob  1"<<endl;
    cout<<"2. Gaddis  6ed Chap4 Prob 10"<<endl;
    cout<<"3. Deitel  7ed Chap2 Prob 23"<<endl;
    cout<<"4. Eckel   3ed Chap1 Prob  9"<<endl;
    cout<<" "<<endl;
    cin>>choose;
    //utilize switch to implement the menu
    switch(choose){
        case 1:{
            cout<<"Place solution to 1 here!"<<endl;
            break;
        }
        case 2:{
            cout<<"Place solution to 10 here!"<<endl;
            break;
        }
        case 3:{
            cout<<"Place solution to 23 here!"<<endl;
            break;
        }
        case 4:{
            cout<<"Place solution to 9 here!"<<endl;
            break;
        }
        default:{
            cout<<"Not an option!"<<endl;
        }
    }
    //exit stage right
    return 0;
}