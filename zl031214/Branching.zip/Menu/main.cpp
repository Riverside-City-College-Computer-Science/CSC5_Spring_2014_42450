/* 
 * File:   main.cpp
 * Author: Zachery Ludwin
 * Created on March 19, 2014, 10:11 AM
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short choose;
    //Prompt user for number of problem to execute
    cout<<"Choose from the following list"<<endl;
    cout<<"1. Savitch 8th Edition Chapter 3 Problem 1"<<endl;
    cout<<"2. Savitch 8th Edition Chapter 3 Problem 2"<<endl;
    cout<<"3. Savitch 8th Edition Chapter 3 Problem 3"<<endl;
    cout<<"4. Savitch 8th Edition Chapter 3 Problem 4"<<endl;
    cin>>choose;
    //Utilize switch to implement the menu
    switch(choose){
        case 1:{
            cout<<"Place solution to 1 here!"<<endl;
            ;break;
        }
        case 2:{
            cout<<"Place solution to 2 here!"<<endl;
            ;break;
        }
        case 3:{
            cout<<"Place solution to 3 here!"<<endl;
            ;break;
        }
        case 4:{
            cout<<"Place solution to 4 here!"<<endl;
            ;break;
        }
    }
    
    return 0;
}

