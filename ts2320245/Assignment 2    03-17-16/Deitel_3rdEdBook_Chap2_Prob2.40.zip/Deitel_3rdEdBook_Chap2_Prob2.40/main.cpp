/* 
 * File:   main.cpp
 * Author: Saldana, Thomas
 * Problem2.40: Write a program that sums a sequence of integers. Assume that the first integer 
 *              read specifies the number of values remaining to be entered. Your Program should 
 *              read only one value per input statement. 
 */
// Sytem Libraries
#include <iostream>// Preprocessor Directive
using namespace std;

//Global Constants

//Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) {
    int sum = 0,  input, value;
    
    cout << "You will be entering as many numbers as you want into this program, and the "
         << "computer will sum up all of those numbers.\n\n";
    cout << "Before the computer can sum up all the numbers you are going to input in however, you must first tell the "
         << "computer how many numbers you wish for it to sum.\n";
    cout << "Input that number in here: ";
    cin >> input;
    // this for structure will initialize, count, and increment all the values that the user inputs.
    for ( int i=1; i<=input; i++){
        cout << "Enter a number: ";
    cin >> value;
    sum = sum + value;
}
    cout << "The sum of all the numbers you just inputed is " << sum << ".\n";
    return 0;
}

