/* 
 * File:   main.cpp
 * Author: Saldana, Thomas
 * Problem 2.43: Write a program that finds the smallest of several integers. Assume that the
 *               first value read specifies the number of values remaining an that the first number 
 *               is not one of the integers to compare. 
 */
//System Libraries
#include <iostream>//Preprocessor Directive
using namespace std;
//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    int integer, valueOfNum, smllstInt;
    //prompt: tells the user what to do
    cout << "You are going to input several integers into the computer, and the computer is going to tell "
         << "you, which of all those integers, is the smallest.\n\n";
    cout << "First, however, enter a number that will tell the computer how "
         << "many integers you wish to process:\n";
    cin >> integer;
    //prompt
    cout << "Now,enter first integer: \n";
    cin >> smllstInt;        
    // this repetetive structure, initializes, counts, and increments in this program.
    for ( int i=2; i<= integer; i++){
        cout <<  "Enter next integer: \n";
        cin >> valueOfNum;
        
        if ( valueOfNum < smllstInt)
            smllstInt=valueOfNum;
    }
    cout <<'\n' << "The smallest of the integers you entered is " << smllstInt << "\n";
    
   return 0;
}

