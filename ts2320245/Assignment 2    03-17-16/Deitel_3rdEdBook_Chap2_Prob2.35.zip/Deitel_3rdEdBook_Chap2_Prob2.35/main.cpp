/* 
 * File:   main.cpp
 * Author: Saldana, Thomas
 *Problem 2.35: Write a program that reads three nonzero double values and 
 *              determines and prints if they could be the sides of a right triangle.
 * 
 */
//System Libraries
#include <iostream>
#include <cmath>//Directives
using namespace std;
//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    int sideA, sideB, sideC;
    
    cout << "Enter the three sides of any triangle, and the computer will tell you "
         << "if those sides could be the sides of a right triangle.\n";
    cin >> sideA >>sideB >>sideC;
    
    // Use the pythogorean theorem : a^2+b^2=c^2
    
    if (pow(sideA,2)+pow(sideB,2)== pow(sideC,2))
        cout << "The sides you entered can be the sides of a right triangle. \n ";
    else 
        cout << "The sides you've entered are not the sides of a right triangle.\n";
    return 0;
}

