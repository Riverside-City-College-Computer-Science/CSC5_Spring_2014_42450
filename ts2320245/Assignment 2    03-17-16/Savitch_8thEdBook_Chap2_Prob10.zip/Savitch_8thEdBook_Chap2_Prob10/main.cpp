/* 
 * File:   main.cpp
 * Author: saldana
 *Problem_SavitchBook: Write a program that reads in ten whole numbers and that outputs 
 *                     the sum of all the numbers greater than zero, the sum of all the numbers less than zero
 *                     ( which will be a negative number or zero), and the sum of all the numbers,
 *                     whether positive, negative, or zero. The user enters the then numbers just once each and the user can enter them in 
 *                     any order. Your program should not ask the user to enter the positive numbers 
 * \                   and the negative numbers separately. 
 */
//System Libraries
#include <iostream>
using namespace std;

// Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    
    
    cout << " Type in ten whole integers, and the computer will tell you the sum of all the numbers "
            <<"greater than zero, less than zero and all the numbers combined.";
float num, sum>0, sum<0, sum, count;


sum>0 = 0;
         sum<0 = 0;
                count = 0;
  
  for (int i = 0; i < 10; i++, count++) {
   cout << "Enter a whole number and press return: ";
   cin >> num;

   if (num <= 0)
   {
   sum<0 += num;
    sum<0 ++;
   }
   else
   {
   sum>0 += num;
    sum>0 ++;
   }
  }


  sum = sum>0 + sum<0;
  
  cout << "The sum of all the numbers greater than zerois: "
       << sum>0
       << '\n';

  cout << "The sum of all the numbers less than zero is:"
       << sum<0
       << '\n';

  cout << "The sum of all the numbers is: "
       << sum
       << endl;

  

  return 0;
 }
