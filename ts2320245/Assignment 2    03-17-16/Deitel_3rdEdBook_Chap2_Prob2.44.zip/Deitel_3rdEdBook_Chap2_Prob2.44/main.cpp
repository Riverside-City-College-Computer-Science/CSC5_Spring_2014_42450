/* 
 * File:   main.cpp
 * Author: Saldana, Thomas
 *Problem 2.44: Write a program that calculates and prints the product of the odd integers from 1 to 15.
 * 
 */
//System Libraries
#include <iostream> // Preprocessor Directive
using namespace std;
// Global Constants

// Function Prototypes

// Exection Begins Here!
int main(int argc, char** argv) {

    // The for structure initializes, counts and increments in a function
    // it also does everything the while structure does, but more concise. 
    int num = 1;
    for ( int i=3; i<=15; i+=2 )
        num *= i;
    cout << " The product of the odd numbers between 1 and 15 is " << num << endl;
        
    
    return 0;
}

