/* 
 * File:   main.cpp
 * Author: Saldana, Thomas
 * Problem 2.41: Write a program that calculates and prints the average of several integers. 
 *               Assume the last value read is the sentinel 9999.
 */
//System Libraries
#include <iostream> // Preprocessor Directives
using namespace std;
// Global Cnts

// Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    
    int num,// Declaration of Variables
     total=0,
    count =0;
    //Prompt
    cout << "Enter several non-zero integers into this program, and the computer will tell you the "
         <<"average of all those integers.\n";
    cout << "When you are done entering all the integers you would like the "
         <<  "computer to average, enter '9999' as your last integer.\n";
    cin >> num;
    // the while structure allows the computer to read line 30-33 over and over before moving on to line 34.
    while ( num != 9999){
        total += num;
      ++count;
    cout << "Enter another integer.\n";
    cin >> num;}

            cout << "The average of all the integers you've entered is " << total/count << endl;
        
    
    

    return 0;
}

