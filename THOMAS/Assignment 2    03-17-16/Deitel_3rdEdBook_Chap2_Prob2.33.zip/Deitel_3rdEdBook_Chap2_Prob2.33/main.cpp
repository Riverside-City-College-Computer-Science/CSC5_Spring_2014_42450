/* 
 * File:   main.cpp
 * Author: Saldana, Thomas
 *Problem 2.33: Write a program taht reads the radius of a circle (as a double value) and computes 
 *              and prints the diameter, the circumference and the area. Use the value 3.14159 for pi.
 * 
 */
//System Libraries
#include <iostream>
#include <cmath>// Preprocessor Directive

using namespace std;
//Global Constants
float pi = 3.14159;

//Function Prototypes


// Execution Begins Here!
int main(int argc, char** argv) {
 
    float radius;
    
    cout << "Enter the radius of any circle, and the computer will compute that circles "
         << "diameter, circumference, and area for you.\n\n";
    cin>> radius;
    
    cout << "The diameter of the circle is " << radius*2 << '\n';
    cout << "The circumference of the circle is " << 2 * pi * radius << '\n';
    cout << "The area of the circle is " << pi * pow(radius,2) << endl;
    return 0;
}

