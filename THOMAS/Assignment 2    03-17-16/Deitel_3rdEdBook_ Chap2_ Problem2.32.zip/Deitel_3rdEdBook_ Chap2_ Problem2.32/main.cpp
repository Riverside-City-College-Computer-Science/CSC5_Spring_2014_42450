/* 
 * File:   main.cpp
 * Author: Saldana, Thomas
 * Problem 2.32: Write a program that keeps printing the multiples of the integer 2, 
 *               namely 2,4,8, 16, 32, 64, etc. Your loop should not termintate (create an 
 *               infinite loop). What happens when you run this program ? 
 */
// System Libraries
#include <iostream> // Preprocessor Directive
using namespace std;
//Global Constants

//Function Prototypes
             
// Execution Begins Here
int main(int argc, char** argv) {
    int num =1, multipleof2;
    
    while (num *= 2 )
        cout <<num << endl;
        
        return 0;
}
/* When I run this program, the multiple of 2 stops at -2.1E^9 for some reason, but I do
 *  not really know why. */
