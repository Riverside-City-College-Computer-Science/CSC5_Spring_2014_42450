/* 
 * File:   main.cpp
 * Author: saldana
 *Problem2.45: Write a prgram that evaluates the factorials of the integers from 1 to 5.
 *             Print the results in tabular format. What difficulty might prvent you from calculating 
 *             the factorial of 20.
 */


// I cannot get this program to work properly. 


// System Libraries 
#include <iostream>// Directives

using namespace std;

// Global Constants

// Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {

    float x;
    cout << "X value" << "\t\t X Factorial"<< endl;
    
    for ( float i =1; i <= 5; ++i){
        x = 1;
        for ( float j = 1 ; j <= i; ++j)
            x *= j;
        cout << i << '\t\t' << x << endl;
    }
    cout << '\n';
    return 0;
}

