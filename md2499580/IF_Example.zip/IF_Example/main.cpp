/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * Created on March 19, 2014, 8:31 AM
 */

//System Libraries
#include <cstdlib>//Random # Generato 
#include <iostream>
#include <ctime>//gives the generator time
using namespace std;
//Global Constants

//Function prototypes

//Execution Begins Here
int main(int argc, char** argv) {
  //Set the random number seed and Declare Variables 
    srand(static_cast<unsigned int>(time(0)));
    char score=rand()%51+50;//gives you a number between 50 and 100
    char grade;
  //What Score corresponds with the correct grade?  
    if(score>89)grade='A';
    if(score<90&&score>79)grade='B';
    if(score<80&&score>69)grade='C';
    if(score<70&&score>59)grade='D';
    if(score<60)grade='F';
  //output the results
    cout<<"A score of "<<static_cast<int>(score)<<" gives a grade = "<<grade<<endl;
  //Exit Stage Right  
    return 0;
}

