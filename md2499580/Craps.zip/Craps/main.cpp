/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * Created on April 9, 2014, 7:55 AM
 * Craps Game
 */

//System libraries
//remove if not needed
#include <cstdlib>//Random Function srand
#include <iostream>//Input & Output
#include <ctime>//Time for random and program
using namespace std;
//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
   //Initialize the Random Number generator
    srand(static_cast<unsigned int>(time(0)));
  //Declare Variables  
    unsigned char sum, sum2, die1, die2;
    unsigned int win=0,win2=0,win3=0,win4=0,win5=0,win6=0,win7=0,win8=0,win9=0,win10=0,win11=0,win12=0;
    unsigned int lose=0, lose2=0,lose3=0,lose4=0,lose5=0,lose6=0,lose7=0,lose8=0,lose9=0,lose10=0,lose11=0,lose12=0;
  //Loop the dice throw  
    unsigned int games=1000000000;
    for(int roll=1; roll<games; roll++){
        //Determine the sum
        die1=rand()%6+1;
        die2=rand()%6+1;
        sum=die1+die2;
        if(sum==7||sum==11){
            win++;
            switch(sum){
                case 7:win7++;break;
                case 11:win11++;break;
                default:cout<<"Better Never Get Here!"<<endl;
            }
        }else if(sum==2||sum==3||sum==12){
            lose++;
            switch(sum){
                case 2:lose7++;break;
                case 3:lose3++;break;
                case 12:lose11++;break;
                default:cout<<"Better Never Get Here!"<<endl;
            }
        }else{
            bool cntloop=true;
            do{
                //roll the dice again
                  die1=rand()%6+1;
                  die2=rand()%6+1;
                  sum2=die1+die2;
                  if(sum2==7){
                      lose++;
                      switch(sum){      
                        case 4:lose4++;break;
                        case 5:lose5++;break;
                        case 6:lose6++;break;
                        case 8:lose8++;break;
                        case 9:lose9++;break;
                        case 10:lose10++;break;
                        default:cout<<"Better Never Get Here!"<<endl;
                      }
                  }while(cntloop);
            }else if(sum==sum2){
                win++;
                
            }
        }
    }
    
    cout<<"Total Wins = "<<win<<" Total loses = "<<lose<<endl;
    cout<<"Total 2 Wins = "<<win2<<" Total 2 loses = "<<lose2<<endl;
    cout<<"Total 3 Wins = "<<win3<<" Total 3 loses = "<<lose3<<endl;
    cout<<"Total 4 Wins = "<<win4<<" Total 4 loses = "<<lose4<<endl;
    cout<<"Total 5 Wins = "<<win5<<" Total 5 loses = "<<lose5<<endl;
    cout<<"Total 6 Wins = "<<win6<<" Total 6 loses = "<<lose6<<endl;   
    cout<<"Total 7 Wins = "<<win7<<" Total 7 loses = "<<lose7<<endl;
    cout<<"Total 8 Wins = "<<win8<<" Total 8 loses = "<<lose8<<endl;
    cout<<"Total 9 Wins = "<<win9<<" Total 9 loses = "<<lose9<<endl;
    cout<<"Total 10 Wins = "<<win10<<" Total 10 loses = "<<lose10<<endl;
    cout<<"Total 11 Wins = "<<win10<<" Total 11 loses = "<<lose11<<endl;
    cout<<"Total 12 Wins = "<<win10<<" Total 12 loses = "<<lose12<<endl;
  //check to determine if it all adds up
    int checkwin=win2+win3+win4+win5+win6+win7+win8+win9+win10+win11+win12;
    int checklose=lose2+lose3+lose4+lose5+lose6+lose7+lose8+lose9+lose10+lose11+lose12;                 
            
  //Exit Stage Right  
    return 0;
}

