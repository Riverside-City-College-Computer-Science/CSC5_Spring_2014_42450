/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * Created on April 28, 2014, 10:00 AM
 * savings function
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <cmath>
using namespace std;
//global Constants

//Function prototypes
float savings1(float, float,int);
float savings2(float, float,int);
float savings3(float, float,int);
float savings4(float, float,int);

//Execution Begins Here
int main(int argc, char** argv) {
  //Declare Variables
    float pv=100.0f, intRate=0.04f, fv;
    int nCmpPer=18;
  //output the inputs
    cout<<"Our Savings Functions"<<endl;
    cout<<"Present Value = $"<<pv<<endl;
    cout<<"Interest Rate = $"<<intRate*100<<endl;    
    cout<<"Present Value = $"<<endl; 
    cout<<"Number of Compounding periods = "<<nCmpPer<<" (years)"<<endl;
  //calculate and output the future value
    cout<<setprecision(2)<<showpoint<<fixed; 
    cout<<"Future Value = $"<<savings1(pv,intRate,nCmpPer)<<endl;
    cout<<"Future Value = $"<<savings2(pv,intRate,nCmpPer)<<endl;    
    cout<<"Future Value = $"<<savings3(pv,intRate,nCmpPer)<<endl; 
    cout<<"Future Value = $"<<savings4(pv,intRate,nCmpPer)<<endl; 
    return 0;
}

float savings4(float balance, float intrst ,int n){
    return balance*exp(n*log(1+intrst));
}

float savings3(float balance, float intrst ,int n){
    if (n==0)return balance;
    return savings3(balance, intrst, n-1)*(1+intrst);
}

float savings2(float balance, float intrst ,int n){
  //loop and calculate the added interest every year  
    for(int year=1;year<=n;year++){
        balance*=(1+intrst);
    }
    return balance;
}

float savings1(float balance, float intrst ,int n){
    return balance*pow(1+intrst),n);
}