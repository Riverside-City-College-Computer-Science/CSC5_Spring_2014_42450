/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * Created on April 9, 2014, 7:55 AM
 * Menu Without Functions 
 */

//System libraries
//remove if not needed
#include <cstdlib>//Random Function srand
#include <iostream>//Input & Output
#include <iomanip>//Formatting
#include <fstream>//File input/ouput
#include <ctime>//Time for random and program
#include <cmath>//Math functions

using namespace std;
//Global Constants
//if not an actual constant get an F!

//Function prototypes

//Execution Begins Here
int main(int argc, char** argv) {
  //Declare menu variables
    int choice; 
    bool extMenu=false;
  //loop until exit
    do{
      //output menu
        cout<<"Choose From the Menu"<<endl;
        cout<<"1. Gaddis/Savitch Ch A Problem X"<<endl;
        cout<<"2. Gaddis/Savitch Ch B Problem Y"<<endl;
        cout<<"3. Gaddis/Savitch Ch C Problem Z"<<endl;
        cout<<"Anything else will exit"<<endl;
      //input choice  
        cin>>choice;
      //solve chosen problem
        switch (choice){
            case 1:{
                cout<<"Put solution to problem 1 here"<<endl;
                cout<<"Everything between main and return"<<endl;
                break;
            }
            case 2:{
                cout<<"Put solution to problem 2 here"<<endl;
                cout<<"Everything between main and return"<<endl;
                break;
                }
            case 3:{
                cout<<"Put solution to problem 3 here"<<endl;
                cout<<"Everything between main and return"<<endl;
                break;
                   }
            default: extMenu=true; 
        }
    }while(!extMenu);
  //Exit Stage Right  
    return 0;
}

