/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * Created on March 17, 2014, 9:33 AM
 * Purpose: Confirm the truth 
 */

//System Libraries
#include <iostream>
using namespace std;
//Global Constants

//Function Prototypes

//Execution Begins Heres
int main(int argc, char** argv) {
   //Declare Variables
    bool X=true;
    bool Y=true;
  //Output the Headings 
    cout<<"X Y !X !Y X||Y X&&Y X^Y X^Y^X X^Y^Y !(X&&Y) !X||Y !(X||Y) !X&&!Y"<<endl;
  //output the first row of the truth table  
    cout<<(X?'T':'F')<<" ";
    cout<<(Y?'T':'F')<<"  ";
    cout<<(!X?'T':'F')<<"  ";
    cout<<(!Y?'T':'F')<<"   ";
    cout<<(X||Y?'T':'F')<<"    ";
    cout<<(X&&Y?'T':'F')<<"  ";
    cout<<endl;
  //Output the Second Row  
    Y=false;
    cout<<(X?'T':'F')<<" ";
    cout<<(Y?'T':'F')<<"  ";
    cout<<(!X?'T':'F')<<"  ";
    cout<<(!Y?'T':'F')<<"   ";
    cout<<(X||Y?'T':'F')<<"    ";
    cout<<(X&&Y?'T':'F')<<"  ";
    cout<<endl;
  //Output the Third Row  
    Y=true;
    X=false;
    cout<<(X?'T':'F')<<" ";
    cout<<(Y?'T':'F')<<"  ";
    cout<<(!X?'T':'F')<<"  ";
    cout<<(!Y?'T':'F')<<"   ";
    cout<<(X||Y?'T':'F')<<"    ";
    cout<<(X&&Y?'T':'F')<<"  ";
    cout<<endl;
  //Output the Fourth Row
    Y=false;
    cout<<(X?'T':'F')<<" ";
    cout<<(Y?'T':'F')<<"  ";
    cout<<(!X?'T':'F')<<"  ";
    cout<<(!Y?'T':'F')<<"   ";
    cout<<(X||Y?'T':'F')<<"    ";
    cout<<(X&&Y?'T':'F')<<"  ";
    cout<<endl;
   //Exit Stage Right 
    return 0;
}

