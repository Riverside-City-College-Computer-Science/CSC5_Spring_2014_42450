/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * Created on May 7, 2014, 9:44 AM
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
  //Initialize the random number generator
    srand(static_cast<unsigned int>(time(0)));
  //Declare Variables
    int cc=rand()%4, plc;
  //output the initial question
    cout<<"Please input your choice:"<<endl;
    cout<<"Rock=1, Paper=2, Scissors=3"<<endl;
    cin>>plc; 
  //the player's choice  
    if(plc==1){
        cout<<"You chose rock"<<endl;
    }else if (plc==2){
        cout<<"You chose paper"<<endl;
    }else if(plc==3){
        cout<<"You chose scissors"<<endl;
    }
  //the computer's choice  
    if (cc==1){
       cout<<"The computer chose rock"<<endl;
    }else if (cc==2){
        cout<<"The computer chose paper"<<endl;
    }else if(cc==3){
        cout<<"The computer chose scissors"<<endl;
    }
  //decide who the winer is and output the results
    if (plc==1&&cc==1){
        cout<<"We have a tie!"<<endl;
    }else if (plc==1&&cc==2){
        cout<<"The computer won!"<<endl;
    }else if (plc==1&&cc==3){
        cout<<"You won!"<<endl;
    }else if (plc==2&&cc==1){
        cout<<"You won!"<<endl;
    }else if (plc==2&&cc==3){
        cout<<"The computer won!"<<endl;
    }else if (plc==2&&cc==2){
        cout<<"We have a tie!"<<endl;
    }else if (plc==3&&cc==1){
        cout<<"The computer won!"<<endl;
    }else if (plc==3&&cc==2){
        cout<<"You won!"<<endl;
    }else if (plc==3&&cc==3){
        cout<<"We have a tie!"<<endl;
    }else{
        cout<<"Error!!!"<<endl;
        cout<<"Try again (its not me its you)"<<endl;
    }
  //Exit Stage Right  
    return 0;
}

