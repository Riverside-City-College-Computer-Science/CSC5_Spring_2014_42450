/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * Created on April 9, 2014, 7:55 AM
 * Menu With Functions 
 */

//System libraries
//remove if not needed
#include <cstdlib>//Random Function srand
#include <iostream>//Input & Output
#include <iomanip>//Formatting
#include <fstream>//File input/ouput
#include <ctime>//Time for random and program
#include <cmath>//Math functions

using namespace std;
//Global Constants
//if not an actual constant get an F!

//Function prototypes
void problem1();
void problem2();
void problem3();

//Execution Begins Here
int main(int argc, char** argv) {
  //Declare menu variables
    int choice; 
    bool extMenu=false;
  //loop until exit
    do{
      //output menu
        cout<<"Choose From the Menu"<<endl;
        cout<<"1. Gaddis/Savitch Ch A Problem X "<<endl;
        cout<<"2. Gaddis/Savitch Ch B Problem Y "<<endl;
        cout<<"3. Gaddis/Savitch Ch C Problem Z "<<endl;
        cout<<"Anything else will exit"<<endl;
      //input choice  
        cin>>choice;
      //solve chosen problem
        switch (choice){
            case 1:problem1();break;
            case 2:problem2();break;
            case 3:problem3();break;
            default: extMenu=true; 
        }
    }while(!extMenu);
  //Exit Stage Right  
    return 0;
}

//Solution to problem 1 here!
  void problem1(){
       cout<<"Put solution to problem 1 here"<<endl;
       cout<<"Everything between main and return"<<endl;
    
}
//Solution to problem 1 here!
  void problem2(){
    cout<<"Put solution to problem 2 here"<<endl;
    cout<<"Everything between main and return"<<endl;
}
//Solution to problem 1 here!
  void problem3(){
    cout<<"Put solution to problem 3 here"<<endl;
    cout<<"Everything between main and return"<<endl;
}
