/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * Created on March 24, 2014, 8:23 AM
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
  //set the random number seed
    srand(static_cast<unsigned int>(time(0)));    
  //pick a random number
    int mybeCsp=rand()%14+14;
    int cspDate=rand()%19+5;
    int diff=mybeCsp-cspDate;
  //output if on the cusp
    if(diff<=2&&diff>=-2){
        cout<<"This Date is on the ";
        cout<<"\"CUSP\""<<endl;
    }
  //output the dates 
    cout<<"The end date of the horiscope = "<<cspDate<<" The birthdate = "<<mybeCsp<<endl;
    
 //Exit Stage Right   
    return 0;
}

