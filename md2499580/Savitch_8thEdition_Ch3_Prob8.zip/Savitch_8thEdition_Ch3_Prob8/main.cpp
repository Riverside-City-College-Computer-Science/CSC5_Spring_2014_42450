/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * Created on March 24, 2014, 7:55 AM
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
  //set the random number generator
    srand(static_cast<unsigned int>(time(0)));
  //Pull First Card
    int card1=rand()%52,numVal1,sum=0;
    char suit1,faceV1;
  //Determine the Card's Suit  
    if(card1<13)suit1='S';
    else if(card1<26)suit1='D';
    else if(card1<39)suit1='C';
    else suit1='H';
    switch(card1%13+1){
        case 1:faceV1='A';numVal1=11;break;
        case 2:faceV1='2';numVal1=2;break;
        case 3:faceV1='3';numVal1=3;break;
        case 4:faceV1='4';numVal1=4;break;
        case 5:faceV1='5';numVal1=5;break;
        case 6:faceV1='6';numVal1=6;break;
        case 7:faceV1='7';numVal1=7;break;
        case 8:faceV1='8';numVal1=8;break;
        case 9:faceV1='9';numVal1=9;break;
        case 10:faceV1='T';numVal1=10;break;
        case 11:faceV1='J';numVal1=10;break;
        case 12:faceV1='Q';numVal1=10;break;
        case 13:faceV1='K';numVal1=10;break;  
    }
    sum+=numVal1;
  //Print the 1st card Pulled
    cout<<"The Sum of your cards = "<<sum<<endl;
    cout<<"The first card you pulled was the "<<faceV1<<suit1<<endl;
    
  //Exit Stage Right
    return 0;
}

