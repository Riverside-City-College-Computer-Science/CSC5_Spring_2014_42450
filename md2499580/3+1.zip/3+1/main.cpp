/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * Created on April 28, 2014, 8:11 AM
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
using namespace std;
//Global Constants

//Function Prototypes
int seqLen(int);  
int rngLen(int, int);

//Execution Begins Here
int main(int argc, char** argv) {
  //Declare Variables
    int strtSeq;//start a sequence
  //randomly choose a sequence start
    srand(static_cast<unsigned int>(time(0)));
    strtSeq=rand()%5+20;//(20, 24)
  //create a variable n and set = to start of sequence with a counter
    int n=strtSeq;
    int counter=-1;
  //loop until n==1
    cout<<n<<" ";
    do{
        //if(n%2==0)n/=2;
        //else n=3*n+1;
        //n=n%2?3*n+1:n/2;
         n=n%2?n+(n<<1)+1:n>>1;
         counter++;
         cout<<n<<" ";
    }while(n>1);
    cout<<endl<<"Seqence Length = "<<counter<<endl;
    cout<<endl<<"Seqence Length = "<<seqLen(strtSeq)<<endl;
    cout<<"for a range of values 20 to the max = "<<rngLen(20,strtSeq)<<endl;
  //Exit Stage Right  
    return 0;
}

int rngLen(int strt, int stp){
  //initiallize the maximum length
    int max=1;
    for(int i=strt;i<=stp;i++){
        int 1en=seqLen(i);
        if(max<1en)max=1en;
    }
   return max;
}

int seqLen(int n){
  //initialize a counter
    int counter=-1;
    do{
         n=n%2?n+(n<<1)+1:n>>1;
         counter++;
    }while(n>1);
  //calculate the sequence length 
    return counter;
}