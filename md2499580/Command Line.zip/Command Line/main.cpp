/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * Created on April 7, 2014, 9:37 AM
 * Fibonacci Sequence  
 */

//System Libraries
#include <iostream>
#include <cstdlib>
using namespace std;
//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
  //Declare Variables
    float income, tax; 
  //output the initial question
    cout<<"Calculate your State Taxes from the $'s which you input"<<endl;
    while(cin>>income){
        if(income<15000){
            tax=0;
        }else if(income<=25000){
            tax=(income-15000)*0.05f;
        }else{
            tax=10000*0.05f+(income-25000)*0.1f;
        }
        cout<<"Income = $"<<income;
        cout<<" Tax = $"<<tax<<endl;
    } 
  //Exit Stage Right  
    return 0;
}

